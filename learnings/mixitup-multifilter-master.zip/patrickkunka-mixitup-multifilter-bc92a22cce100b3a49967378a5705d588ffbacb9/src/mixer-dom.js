/* global mixitup */

mixitup.MixerDom.registerAction('afterConstruct', 'multifilter', function() {
    this.filterGroups = [];
});