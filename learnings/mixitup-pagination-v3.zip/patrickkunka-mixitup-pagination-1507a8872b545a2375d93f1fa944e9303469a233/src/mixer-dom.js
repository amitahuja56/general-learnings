/* global mixitup */

mixitup.MixerDom.registerAction('afterConstruct', 'pagination', function() {
    this.pageListEls  = [];
    this.pageStatsEls = [];
});