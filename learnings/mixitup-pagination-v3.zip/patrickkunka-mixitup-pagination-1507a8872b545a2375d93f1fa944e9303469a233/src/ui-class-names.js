/* global mixitup */

mixitup.UiClassNames.registerAction('afterConstruct', 'pagination', function() {
    this.first              = '';
    this.last               = '';
    this.prev               = '';
    this.next               = '';
    this.first              = '';
    this.last               = '';
    this.truncated          = '';
    this.truncationMarker   = '';
});