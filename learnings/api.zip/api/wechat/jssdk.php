<?php
 error_reporting(1);
 include '/api/class.database.php';

class JSSDK {
  private $appId;
  private $appSecret;
  private $dataTicket;
  private $dataTicketTimestamp;
  private $dataToken;
  private $dataTokenTimestamp;

  public function __construct($appId, $appSecret) {
    $this->appId = $appId;
    $this->appSecret = $appSecret;

    // Get previous wechat ticket and token data
    $this->getWeChatConfigFromDB();
  }

  public function getWeChatConfigFromDB() {

    // echo "Function: " . "getWeChatConfigFromDB" . "<br/>";

    $db = Database::getInstance();
    $mysqli = $db->getConnection();
    $query = "SELECT * FROM wechat_config WHERE id = 1";
    $result =$mysqli->query($query);
    $row = $result->fetch_array(MYSQLI_ASSOC);

    $this->dataTicket = $row["ticket"];
    $this->dataTicketTimestamp = $row["ticket_expiry_timestamp"];
    $this->dataToken = $row["token"];
    $this->dataTokenTimestamp = $row["token_expiry_timestamp"];

    // echo "dataTicket: " . $this->dataTicket . "<br/>";
    // echo "dataTicketTimestamp: " . $this->dataTicketTimestamp . "<br/>";
    // echo "dataToken: " . $this->dataToken . "<br/>";
    // echo "dataTokenTimestamp: " . $this->dataTokenTimestamp . "<br/>";

    $result->free();

  }


  public function updateWeChatConfigFromDB($func) {

    // echo "Function: " . "updateWeChatConfigFromDB for " . $func . "<br/>";

    // echo "dataTicket: " . $this->dataTicket . "<br/>";
    // echo "dataTicketTimestamp: " . $this->dataTicketTimestamp . "<br/>";
    // echo "dataToken: " . $this->dataToken . "<br/>";
    // echo "dataTokenTimestamp: " . $this->dataTokenTimestamp . "<br/>";

    $db = Database::getInstance();
    $mysqli = $db->getConnection(); 

    if ($mysqli->connect_errno) {
      printf("Connect failed: %s\n", $mysqli->connect_error);
      exit();
    }

    $query = "UPDATE wechat_config";
    if($func == "ticket") {
      $query .= " SET ticket = '".$this->dataTicket."'";
      $query .= ", ticket_expiry_timestamp = '".$this->dataTicketTimestamp."'";
    }
    else {
      $query .= " SET token = '".$this->dataToken."'";
      $query .= ", token_expiry_timestamp = '".$this->dataTokenTimestamp."'";

    }
    $query .= " WHERE id = 1";

    // echo "query: " . $query . "<br/>";

    $result = $mysqli->query($query) or die($mysqli->error);

    // echo "query error: " . $mysqli->error . "<br/>";

    $query = "SELECT * FROM wechat_config WHERE id = 1";
    $result =$mysqli->query($query);
    $row = $result->fetch_array(MYSQLI_ASSOC);

    // echo "dataTicket: " . $row["ticket"] . "<br/>";
    // echo "dataTicketTimestamp: " . $row["ticket_expiry_timestamp"] . "<br/>";
    // echo "dataToken: " . $row["token"] . "<br/>";
    // echo "dataTokenTimestamp: " . $row["token_expiry_timestamp"] . "<br/>";

    // echo "<br/><hr/>";

    $result->free();
        
  }



  public function getSignPackage() {

    // echo "Function: " . "getSignPackage" . "<br/>";

    $jsapiTicket = $this->getJsApiTicket();

    // 注意 URL 一定要动态获取，不能 hardcode.
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    $url = "$protocol$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

    $timestamp = time();
    $nonceStr = $this->createNonceStr();

    // 这里参数的顺序要按照 key 值 ASCII 码升序排序
    $string = "jsapi_ticket=$jsapiTicket&noncestr=$nonceStr&timestamp=$timestamp&url=$url";

    // echo "jsapi_ticket: " . $string . "<br/>";

    $signature = sha1($string);

    // echo "signature: " . $signature . "<br/>";

    $signPackage = array(
      "appId"     => $this->appId,
      "nonceStr"  => $nonceStr,
      "timestamp" => $timestamp,
      "url"       => $url,
      "signature" => $signature,
      "rawString" => $string
    );
    return $signPackage; 
  }

  private function createNonceStr($length = 16) {
    $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    $str = "";
    for ($i = 0; $i < $length; $i++) {
      $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
    }
    return $str;
  }

  private function getJsApiTicket() {

    // echo "Function: " . "getJsApiTicket" . "<br/>";

    if ($this->dataTicketTimestamp < time()) {

      $accessToken = $this->getAccessToken();
      
      // 如果是企业号用以下 URL 获取 ticket
      // $url = "https://qyapi.weixin.qq.com/cgi-bin/get_jsapi_ticket?access_token=$accessToken";
      $url = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?type=jsapi&access_token=$accessToken";
      $res = json_decode($this->httpGet($url));
      $ticket = $res->ticket;
      $expires_in = $res->expires_in;
      
      if ($ticket) {

        $this->dataTicket = $ticket;
        $this->dataTicketTimestamp = time() + $expires_in;
        
        // echo "dataTicket: " . $this->dataTicket . "<br/>";
        // echo "dataTicketTimestamp: " . $this->dataTicketTimestamp . "<br/>";

        // Store in database
        $this->updateWeChatConfigFromDB("ticket");
      }
    } else {
      $ticket = $this->dataTicket;
    }

    return $ticket;
  }

  private function getAccessToken() {

    // echo "Function: " . "getAccessToken" . "<br/>";

    if ($dataTokenTimestamp < time()) {

      // echo "timestamp is outdated<br/>";

      // 如果是企业号用以下URL获取access_token
      // $url = "https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=$this->appId&corpsecret=$this->appSecret";
      $url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=$this->appId&secret=$this->appSecret";
      $res = json_decode($this->httpGet($url));
      $access_token = $res->access_token;
      $expires_in = $res->expires_in;

      if ($access_token) {

        // echo "access_token: ".$access_token."<br/>";

        $this->dataToken = $access_token;
        $this->dataTokenTimestamp = time() + $expires_in;

        // echo "dataToken: " . $this->dataToken . "<br/>";
        // echo "dataTokenTimestamp: " . $this->dataTokenTimestamp . "<br/>";

        // Store in database
        $this->updateWeChatConfigFromDB("token");
      }
    } else {
      $access_token = $this->dataToken;
    }
    return $access_token;
  }

  private function httpGet($url) {
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_TIMEOUT, 500);
    // 为保证第三方服务器与微信服务器之间数据传输的安全性，所有微信接口采用https方式调用，必须使用下面2行代码打开ssl安全校验。
    // 如果在部署过程中代码在此处验证失败，请到 http://curl.haxx.se/ca/cacert.pem 下载新的证书判别文件。
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, true);
    curl_setopt($curl, CURLOPT_URL, $url);

    $res = curl_exec($curl);
    curl_close($curl);

    return $res;
  }

}

