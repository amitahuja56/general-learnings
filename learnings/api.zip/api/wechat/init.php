<?php

require_once "jssdk.php";

$jssdk = new JSSDK("wx9954453e7fcc0148", "42f5c3dbf0e7295a61aefae57d629db8");

echo json_encode($jssdk->getSignPackage(), JSON_FORCE_OBJECT);

// echo json_encode($jssdk->getSignPackage());


?>